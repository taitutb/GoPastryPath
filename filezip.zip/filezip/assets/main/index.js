window.__require = function t(e, a, n) {
function s(o, i) {
if (!a[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (r) return r(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
o = c;
}
var u = a[o] = {
exports: {}
};
e[o][0].call(u.exports, function(t) {
return s(e[o][1][t] || t);
}, u, u.exports, t, e, a, n);
}
return a[o].exports;
}
for (var r = "function" == typeof __require && __require, o = 0; o < n.length; o++) s(n[o]);
return s;
}({
HotUpdate: [ function(t, e, a) {
"use strict";
cc._RF.push(e, "46e44JZ8txJgKVjiTaCL+/x", "HotUpdate");
var n, s = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
})(t, e);
}, function(t, e) {
n(t, e);
function a() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (a.prototype = e.prototype, new a());
}), r = this && this.__decorate || function(t, e, a, n) {
var s, r = arguments.length, o = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, a) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, e, a, n); else for (var i = t.length - 1; i >= 0; i--) (s = t[i]) && (o = (r < 3 ? s(o) : r > 3 ? s(e, a, o) : s(e, a)) || o);
return r > 3 && o && Object.defineProperty(e, a, o), o;
};
Object.defineProperty(a, "__esModule", {
value: !0
});
var o = cc._decorator, i = o.ccclass, c = o.property, l = function(t) {
s(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.manifestUrl = null;
e.loadingBar = null;
e.lb_Info = null;
e._updating = !1;
e._failCount = 0;
e._canRetry = !1;
e._storagePath = "";
e._updateListener = null;
e._am = null;
e._checkListener = null;
e.versionCompareHandle = null;
e.gameSceneName = "main";
return e;
}
e.prototype.onLoad = function() {
cc.sys.isNative && (cc.Device ? cc.Device.setKeepScreenOn(!0) : jsb.Device && jsb.Device.setKeepScreenOn(!0));
cc.sys.isNative ? this.initHotUpdate() : this.loadGame();
};
e.prototype.initHotUpdate = function() {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "mini16-remote-asset";
cc.log("Storage path for remote asset : " + this._storagePath);
this.versionCompareHandle = function(t, e) {
cc.log("JS Custom Version Compare: version A is " + t + ", version B is " + e);
for (var a = t.split("."), n = e.split("."), s = 0; s < a.length; ++s) {
var r = parseInt(a[s]), o = parseInt(n[s] || 0);
if (r !== o) return r - o;
}
return n.length > a.length ? -1 : 0;
};
this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
this._am.setVerifyCallback(function(t, e) {
e.compressed;
return !0;
});
cc.sys.os === cc.sys.OS_ANDROID && this._am.setMaxConcurrentTask(2);
this.hotUpdate();
};
e.prototype.loadGame = function() {
var t = this, e = 0;
t.loadingBar.fillRange = 0;
console.log("lobby");
cc.director.preloadScene("lobby", function(a, n) {
var s = 100 * a / n;
s > e && (e = s);
t.loadingBar.fillRange = e / 100;
}, function() {
cc.director.loadScene("lobby", function() {});
});
};
e.prototype.updateCb = function(t) {
var e = !1, a = !1;
cc.log("---eventCode:" + t.getEventCode());
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
a = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var n = t.getMessage();
n && cc.log("Progress" + t.getPercent() / 100 + "% : " + n);
this.loadingBar.fillRange = t.getPercent();
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
a = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
a = !0;
this.loadGame();
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this._updating = !1;
this._canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
case jsb.EventAssetsManager.ERROR_DECOMPRESS:
}
cc.log("---needStar" + e);
if (a) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var s = jsb.fileUtils.getSearchPaths(), r = this._am.getLocalManifest().getSearchPaths();
cc.log(JSON.stringify(r));
Array.prototype.unshift.apply(s, r);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(s));
jsb.fileUtils.setSearchPaths(s);
cc.audioEngine.stopAll();
cc.game.restart();
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (t = cc.loader.md5Pipe.transformURL(t));
this._am.loadLocalManifest(t);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
r([ c({
type: cc.Asset
}) ], e.prototype, "manifestUrl", void 0);
r([ c(cc.Sprite) ], e.prototype, "loadingBar", void 0);
r([ c(cc.Label) ], e.prototype, "lb_Info", void 0);
return r([ i ], e);
}(cc.Component);
a.default = l;
cc._RF.pop();
}, {} ],
LoadGameController: [ function(t, e, a) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var n, s = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
})(t, e);
}, function(t, e) {
n(t, e);
function a() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (a.prototype = e.prototype, new a());
}), r = this && this.__decorate || function(t, e, a, n) {
var s, r = arguments.length, o = r < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, a) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, e, a, n); else for (var i = t.length - 1; i >= 0; i--) (s = t[i]) && (o = (r < 3 ? s(o) : r > 3 ? s(e, a, o) : s(e, a)) || o);
return r > 3 && o && Object.defineProperty(e, a, o), o;
}, o = this && this.__awaiter || function(t, e, a, n) {
return new (a || (a = Promise))(function(s, r) {
function o(t) {
try {
c(n.next(t));
} catch (t) {
r(t);
}
}
function i(t) {
try {
c(n.throw(t));
} catch (t) {
r(t);
}
}
function c(t) {
t.done ? s(t.value) : (e = t.value, e instanceof a ? e : new a(function(t) {
t(e);
})).then(o, i);
var e;
}
c((n = n.apply(t, e || [])).next());
});
}, i = this && this.__generator || function(t, e) {
var a, n, s, r, o = {
label: 0,
sent: function() {
if (1 & s[0]) throw s[1];
return s[1];
},
trys: [],
ops: []
};
return r = {
next: i(0),
throw: i(1),
return: i(2)
}, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
return this;
}), r;
function i(t) {
return function(e) {
return c([ t, e ]);
};
}
function c(r) {
if (a) throw new TypeError("Generator is already executing.");
for (;o; ) try {
if (a = 1, n && (s = 2 & r[0] ? n.return : r[0] ? n.throw || ((s = n.return) && s.call(n), 
0) : n.next) && !(s = s.call(n, r[1])).done) return s;
(n = 0, s) && (r = [ 2 & r[0], s.value ]);
switch (r[0]) {
case 0:
case 1:
s = r;
break;

case 4:
o.label++;
return {
value: r[1],
done: !1
};

case 5:
o.label++;
n = r[1];
r = [ 0 ];
continue;

case 7:
r = o.ops.pop();
o.trys.pop();
continue;

default:
if (!(s = o.trys, s = s.length > 0 && s[s.length - 1]) && (6 === r[0] || 2 === r[0])) {
o = 0;
continue;
}
if (3 === r[0] && (!s || r[1] > s[0] && r[1] < s[3])) {
o.label = r[1];
break;
}
if (6 === r[0] && o.label < s[1]) {
o.label = s[1];
s = r;
break;
}
if (s && o.label < s[2]) {
o.label = s[2];
o.ops.push(r);
break;
}
s[2] && o.ops.pop();
o.trys.pop();
continue;
}
r = e.call(t, o);
} catch (t) {
r = [ 6, t ];
n = 0;
} finally {
a = s = 0;
}
if (5 & r[0]) throw r[1];
return {
value: r[0] ? r[1] : void 0,
done: !0
};
}
};
Object.defineProperty(a, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, u = c.property;
function p(t, e) {
for (var a = t.split("."), n = e.split("."), s = 0; s < a.length; ++s) {
var r = parseInt(a[s]), o = parseInt(n[s] || "0");
if (r !== o) return r - o;
}
return n.length > a.length ? -1 : 0;
}
var f = function(t) {
s(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingSprite = null;
e.loadingLabel = null;
e.lbInfo = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
e.gameInfo = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "mini16-remote-asset";
this._am = new jsb.AssetsManager("", this._storagePath, p);
this._am.setVerifyCallback(function(t, e) {
var a = e.compressed, n = e.md5, s = e.path;
e.size;
if (a) {
cc.log("Verification passed : " + s);
return !0;
}
cc.log("Verification passed : " + s + " (" + n + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return o(this, void 0, void 0, function() {
var t = this;
return i(this, function() {
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
this.onCheckGame("https://hotgame17.k79.info/remote-assets/LoadingScene");
return [ 2 ];
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e, a = new jsb.Manifest((e = t, JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(a, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, a = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var n = t.getDownloadedBytes() / t.getTotalBytes();
t.getMessage();
this.updateProcess(n);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
try {
cc.director.loadScene("Loading");
} catch (t) {}
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
a = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
a = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
a = !0;
}
if (a) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var s = jsb.fileUtils.getSearchPaths(), r = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(s, r);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(s));
cc.log(JSON.stringify(r));
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
cc.log("Updated file: " + t);
this.loadingSprite.fillRange = t;
this.loadingLabel.string = "Update " + Math.round(100 * t) + "%";
};
r([ u(cc.Sprite) ], e.prototype, "loadingSprite", void 0);
r([ u(cc.Label) ], e.prototype, "loadingLabel", void 0);
r([ u(cc.Label) ], e.prototype, "lbInfo", void 0);
return r([ l ], e);
}(cc.Component);
a.default = f;
cc._RF.pop();
}, {} ]
}, {}, [ "HotUpdate", "LoadGameController" ]);